"""
CARLA live-drive harness — main entry point.

All ``carla`` imports are lazy so ordinary installs and CI remain
unaffected.  The harness is opt-in; run it explicitly via::

    python -m qrtc.carla_harness
    # or
    carla-live-drive

Environment variables:
    See qrtc.carla_config for the full list.

Safety guarantee
----------------
``carla`` is never imported at module load time.  If it is not installed
the module can still be imported; only the :func:`run_drive` function
(and the ``__main__`` block) will fail with an ImportError that includes
installation guidance.
"""

from __future__ import annotations

import argparse
import json
import math
import sys
import traceback
import uuid
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from qrtc.carla_config import CarlaConfig, carla_config_from_env, validate_carla_config
from qrtc.carla_lidar import LidarCollector, LidarCollectorSnapshot, build_lidar_summary
from qrtc.carla_telemetry import build_qrtc_projection, submit_to_qrtc_pipeline
from qrtc.runtime_protection import (
    RuntimeProtection,
    RuntimeProtectionConfig,
    RuntimeProtectionState,
)

# ---------------------------------------------------------------------------
# CARLA lazy import helper
# ---------------------------------------------------------------------------


def _require_carla() -> Any:
    """Import and return the ``carla`` module, or raise ImportError with help."""
    try:
        import carla  # type: ignore[import]

        return carla
    except ImportError as exc:
        raise ImportError(
            "CARLA Python API is not installed. "
            "Install it from the CARLA 0.9.16 release (requires CPython 3.12):\n"
            "  pip install <path-to-carla-0.9.16-cp312-*.whl>\n"
            "See qrtc-transit/README.md for full setup instructions."
        ) from exc


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _displacement(
    start: tuple[float, float, float],
    end: tuple[float, float, float],
) -> float:
    dx, dy, dz = end[0] - start[0], end[1] - start[1], end[2] - start[2]
    return math.sqrt(dx * dx + dy * dy + dz * dz)


def _transform_snapshot(transform: Any, velocity: Any) -> dict[str, Any]:
    loc = transform.location
    rot = transform.rotation
    speed = math.sqrt(velocity.x**2 + velocity.y**2 + velocity.z**2)
    return {
        "x": loc.x,
        "y": loc.y,
        "z": loc.z,
        "pitch": rot.pitch,
        "yaw": rot.yaw,
        "roll": rot.roll,
        "vx": velocity.x,
        "vy": velocity.y,
        "vz": velocity.z,
        "speed_mps": speed,
    }


def _select_blueprint(blueprint_library: Any, preferred: str) -> Any:
    """Choose ``preferred`` or fall back deterministically."""
    bp = blueprint_library.find(preferred)
    if bp is not None:
        return bp
    # Deterministic fallback: sort by id, pick first vehicle
    vehicles = sorted(
        blueprint_library.filter("vehicle.*"),
        key=lambda b: b.id,
    )
    if not vehicles:
        raise RuntimeError("No vehicle blueprints found in the simulator")
    return vehicles[0]


def _try_spawn(
    world: Any,
    blueprint: Any,
    spawn_points: list[Any],
    preferred_index: int,
) -> tuple[Any, int]:
    """
    Try the requested spawn point, then all others in order.
    Return (actor, actual_index_used).
    """
    indices = list(range(len(spawn_points)))
    if preferred_index < len(indices):
        indices = [preferred_index] + [i for i in indices if i != preferred_index]

    for idx in indices:
        actor = world.try_spawn_actor(blueprint, spawn_points[idx])
        if actor is not None:
            return actor, idx

    raise RuntimeError(
        f"Could not spawn vehicle at any of {len(spawn_points)} spawn points"
    )


@dataclass(frozen=True)
class PostRunClassification:
    test_outcome: str
    post_run_rejection_test_passed: bool
    fault_requested: bool
    fault_observed: bool


def _classify_post_run_rejection(
    cfg: CarlaConfig,
    run_report: dict[str, Any],
    qrtc_submission: dict[str, Any] | None = None,
) -> PostRunClassification:
    """Classify the run's post-run fault-injection outcome."""
    fault_requested = cfg.lidar.drop_frame_index >= 0
    fault_injection = run_report.get("fault_injection") or {}
    fault_observed = bool(fault_injection.get("triggered"))

    if not fault_requested:
        return PostRunClassification(
            test_outcome="no_fault_injection",
            post_run_rejection_test_passed=False,
            fault_requested=False,
            fault_observed=False,
        )

    if not fault_observed:
        return PostRunClassification(
            test_outcome="invalid_fault_injection",
            post_run_rejection_test_passed=False,
            fault_requested=True,
            fault_observed=False,
        )

    ticks_requested = run_report.get("ticks_requested")
    ticks_completed = run_report.get("ticks_completed")
    lidar_callbacks_received = run_report.get("lidar_callbacks_received")
    lidar_frames_accepted = run_report.get("lidar_frames_accepted")
    lidar_frames_natural_dropped = run_report.get("lidar_frames_natural_dropped")
    lidar_frames_injected_dropped = run_report.get("lidar_frames_injected_dropped")
    lidar_callback_errors = (run_report.get("lidar_summary") or {}).get(
        "callback_errors"
    )

    callback_accounting_consistent = (
        lidar_callbacks_received is not None
        and lidar_frames_accepted is not None
        and lidar_frames_injected_dropped is not None
        and lidar_callback_errors is not None
        and lidar_callbacks_received
        == (
            lidar_frames_accepted
            + lidar_frames_injected_dropped
            + lidar_callback_errors
        )
    )

    health_guard_failed = False
    qrtc_status = None
    evidence_preserved = False
    if qrtc_submission is not None:
        qrtc_status = qrtc_submission.get("status")
        evidence_preserved = bool(qrtc_submission.get("evidence_preserved"))
        for guard_reason in qrtc_submission.get("guard_reasons") or ():
            if (
                guard_reason.get("guard_id") == "carla-health-v1"
                and guard_reason.get("qualified") is False
            ):
                health_guard_failed = True
                break

    post_run_passed = (
        qrtc_submission is not None
        and fault_injection.get("triggered_callback_index")
        == cfg.lidar.drop_frame_index
        and isinstance(ticks_requested, int)
        and ticks_completed == ticks_requested
        and lidar_callbacks_received == ticks_requested
        and lidar_frames_accepted == ticks_requested - 1
        and lidar_frames_injected_dropped == 1
        and lidar_frames_natural_dropped == 0
        and lidar_callback_errors == 0
        and callback_accounting_consistent
        and qrtc_status == "rejected"
        and health_guard_failed
        and evidence_preserved
    )
    return PostRunClassification(
        test_outcome=(
            "post_run_rejection_pass" if post_run_passed else "post_run_rejection_fail"
        ),
        post_run_rejection_test_passed=post_run_passed,
        fault_requested=True,
        fault_observed=True,
    )


@dataclass(frozen=True)
class RuntimeProtectionClassification:
    test_outcome: str
    runtime_protection_test_passed: bool


def _classify_runtime_protection(
    cfg: CarlaConfig,
    run_report: dict[str, Any],
    qrtc_submission: dict[str, Any] | None = None,
) -> RuntimeProtectionClassification:
    """
    Classify the run's runtime-protection outcome.

    Returns a passing result only when ALL of the following are true:
    - runtime protection was enabled and triggered
    - autopilot was disabled
    - safe stop was confirmed
    - no stop timeout occurred
    - run was terminated early
    - injected fault actually triggered
    - exactly one injected drop
    - zero natural drops for the controlled injection test
    - QRTC status is 'rejected'
    - rejection includes carla-health-v1 with qualified == false
    - evidence was preserved
    """
    if not cfg.runtime_protection_enabled:
        return RuntimeProtectionClassification(
            test_outcome="runtime_protection_disabled",
            runtime_protection_test_passed=False,
        )

    rp_snap = run_report.get("runtime_protection")
    if rp_snap is None:
        return RuntimeProtectionClassification(
            test_outcome="runtime_protection_failed",
            runtime_protection_test_passed=False,
        )

    fault_triggered = bool(rp_snap.get("fault_triggered"))
    autopilot_disabled = bool(rp_snap.get("autopilot_disabled"))
    safe_stop = bool(rp_snap.get("safe_stop"))
    stop_timeout = bool(rp_snap.get("stop_timeout"))
    control_action_failed = bool(rp_snap.get("control_action_failed"))
    rp_state = rp_snap.get("state")

    if control_action_failed or rp_state == RuntimeProtectionState.CONTROL_ERROR.value:
        return RuntimeProtectionClassification(
            test_outcome="runtime_protection_control_error",
            runtime_protection_test_passed=False,
        )

    if stop_timeout:
        return RuntimeProtectionClassification(
            test_outcome="runtime_protection_stop_timeout",
            runtime_protection_test_passed=False,
        )

    terminated_early = bool(run_report.get("terminated_early"))
    fault_injection = run_report.get("fault_injection") or {}
    fault_requested = cfg.lidar.drop_frame_index >= 0
    fault_observed = bool(fault_injection.get("triggered"))
    injected_drops = run_report.get("lidar_frames_injected_dropped", 0)
    natural_drops = run_report.get("lidar_frames_natural_dropped", 0)

    qrtc_status = None
    evidence_preserved = False
    carla_health_qualified_false = False
    if qrtc_submission is not None:
        qrtc_status = qrtc_submission.get("status")
        evidence_preserved = bool(qrtc_submission.get("evidence_preserved"))
        for guard_reason in qrtc_submission.get("guard_reasons") or ():
            if (
                guard_reason.get("guard_id") == "carla-health-v1"
                and guard_reason.get("qualified") is False
            ):
                carla_health_qualified_false = True
                break

    rp_passed = bool(
        cfg.runtime_protection_enabled
        and fault_triggered
        and autopilot_disabled
        and safe_stop
        and not stop_timeout
        and terminated_early
        and fault_requested
        and fault_observed
        and injected_drops == 1
        and natural_drops == 0
        and qrtc_status == "rejected"
        and carla_health_qualified_false
        and evidence_preserved
    )

    return RuntimeProtectionClassification(
        test_outcome=(
            "runtime_protection_pass" if rp_passed else "runtime_protection_failed"
        ),
        runtime_protection_test_passed=rp_passed,
    )


# ---------------------------------------------------------------------------
# Core drive function
# ---------------------------------------------------------------------------


def run_drive(cfg: CarlaConfig | None = None) -> dict[str, Any]:
    """
    Execute a bounded synchronous CARLA drive and return a detailed run report.

    This function:
    - connects to CARLA using ``cfg`` (defaults to :func:`carla_config_from_env`)
    - enables synchronous mode and Traffic Manager
    - spawns a vehicle, attaches collision and (optionally) lidar sensors
    - runs for ``cfg.ticks`` frames
    - always cleans up in a ``finally`` block
    - returns a report dict (also written to ``cfg.output``)

    Raises ``SystemExit`` with a non-zero code on connection/spawn/tick/output
    failures so the process exit code signals CI correctly.
    """
    carla = _require_carla()

    if cfg is None:
        cfg = carla_config_from_env()

    errors = validate_carla_config(cfg)
    if errors:
        for e in errors:
            print(f"[carla-harness] config error: {e}", file=sys.stderr)
        raise SystemExit(1)

    run_id = str(uuid.uuid4())
    run_ts = datetime.now(UTC).isoformat()
    print(f"[carla-harness] run_id={run_id} ts={run_ts}", flush=True)

    # --- Connect ----------------------------------------------------------------
    try:
        client = carla.Client(cfg.host, cfg.port)
        client.set_timeout(cfg.timeout)
        client_version = client.get_client_version()
        server_version = client.get_server_version()
        world = client.get_world()
        map_name = world.get_map().name
    except Exception as exc:
        print(f"[carla-harness] connection failed: {exc}", file=sys.stderr)
        traceback.print_exc()
        raise SystemExit(2) from exc

    print(
        f"[carla-harness] client={client_version} server={server_version} map={map_name}",
        flush=True,
    )

    # Save and later restore original world settings
    original_settings = world.get_settings()
    settings = world.get_settings()
    settings.synchronous_mode = True
    settings.fixed_delta_seconds = cfg.fixed_delta
    world.apply_settings(settings)

    # Traffic Manager
    tm = client.get_trafficmanager(cfg.tm_port)
    tm.set_synchronous_mode(True)

    ego_vehicle = None
    collision_sensor = None
    lidar_sensor = None
    lidar_collector: LidarCollector | None = None
    collision_events: list[dict[str, Any]] = []
    samples: list[dict[str, Any]] = []
    missing_data_count = 0

    try:
        # --- Spawn vehicle --------------------------------------------------
        blueprint_library = world.get_blueprint_library()
        blueprint = _select_blueprint(blueprint_library, cfg.preferred_blueprint)
        spawn_points = world.get_map().get_spawn_points()
        if not spawn_points:
            raise RuntimeError("World has no spawn points")

        try:
            ego_vehicle, actual_spawn_index = _try_spawn(
                world, blueprint, spawn_points, cfg.spawn_point
            )
        except RuntimeError as exc:
            print(f"[carla-harness] spawn failed: {exc}", file=sys.stderr)
            raise SystemExit(3) from exc

        actor_id = ego_vehicle.id
        actor_type_id = ego_vehicle.type_id
        print(
            f"[carla-harness] spawned {actor_type_id} id={actor_id} "
            f"spawn_point={actual_spawn_index}",
            flush=True,
        )

        # Enable conservative autopilot
        ego_vehicle.set_autopilot(True, cfg.tm_port)
        tm.ignore_lights_percentage(ego_vehicle, 0)
        tm.distance_to_leading_vehicle(ego_vehicle, 3.0)
        tm.vehicle_percentage_speed_difference(ego_vehicle, 20.0)

        # --- Collision sensor -----------------------------------------------
        collision_bp = blueprint_library.find("sensor.other.collision")
        collision_transform = carla.Transform()
        collision_sensor = world.spawn_actor(
            collision_bp, collision_transform, attach_to=ego_vehicle
        )

        def _on_collision(event: Any) -> None:
            other = getattr(event.other_actor, "type_id", "unknown")
            collision_events.append(
                {
                    "frame": event.frame,
                    "other_actor": other,
                    "impulse_x": event.normal_impulse.x,
                    "impulse_y": event.normal_impulse.y,
                    "impulse_z": event.normal_impulse.z,
                }
            )

        collision_sensor.listen(_on_collision)

        # --- Lidar sensor ---------------------------------------------------
        if cfg.lidar.enabled:
            lidar_bp = blueprint_library.find("sensor.lidar.ray_cast")
            if lidar_bp is None:
                print(
                    "[carla-harness] lidar blueprint not found; skipping lidar",
                    file=sys.stderr,
                )
            else:
                lidar_bp.set_attribute("channels", str(cfg.lidar.channels))
                lidar_bp.set_attribute("range", str(cfg.lidar.range_m))
                lidar_bp.set_attribute(
                    "points_per_second", str(cfg.lidar.points_per_second)
                )
                lidar_bp.set_attribute(
                    "rotation_frequency", str(cfg.lidar.rotation_frequency)
                )
                lidar_bp.set_attribute("upper_fov", str(cfg.lidar.upper_fov))
                lidar_bp.set_attribute("lower_fov", str(cfg.lidar.lower_fov))

                lidar_transform = carla.Transform(carla.Location(x=0.0, z=2.4))
                lidar_sensor = world.spawn_actor(
                    lidar_bp, lidar_transform, attach_to=ego_vehicle
                )
                lidar_collector = LidarCollector(
                    retain_raw=cfg.lidar.retain_raw,
                    max_raw_frames=cfg.lidar.max_raw_frames,
                    drop_frame_index=cfg.lidar.drop_frame_index,
                )
                lidar_sensor.listen(lidar_collector.on_data)

        # --- Runtime protection supervisor ----------------------------------
        rp_cfg = RuntimeProtectionConfig(
            enabled=cfg.runtime_protection_enabled,
            stop_speed_mps=cfg.runtime_stop_speed_mps,
            required_stopped_ticks=cfg.runtime_required_stopped_ticks,
            maximum_braking_ticks=cfg.runtime_maximum_braking_ticks,
            full_brake=cfg.runtime_full_brake,
        )
        rp_supervisor = RuntimeProtection(rp_cfg)
        if cfg.runtime_protection_enabled and lidar_collector is not None:
            lidar_collector.fault_notify = rp_supervisor.latch_fault

        def _disable_autopilot(vehicle: Any) -> None:
            vehicle.set_autopilot(False)

        def _apply_braking_control(
            vehicle: Any, throttle: float, brake: float, steer: float
        ) -> None:
            ctrl = carla.VehicleControl()
            ctrl.throttle = throttle
            ctrl.brake = brake
            ctrl.steer = steer
            vehicle.apply_control(ctrl)

        # --- Tick loop ------------------------------------------------------
        initial_transform = ego_vehicle.get_transform()
        start_pos = (
            initial_transform.location.x,
            initial_transform.location.y,
            initial_transform.location.z,
        )
        speed_values: list[float] = []
        ticks_completed = 0

        try:
            for tick_idx in range(cfg.ticks):
                frame = world.tick()
                ticks_completed += 1

                if cfg.runtime_protection_enabled and lidar_collector is not None:
                    frame_state = lidar_collector.wait_for_frame(
                        frame,
                        cfg.runtime_lidar_callback_timeout_seconds,
                    )
                    if frame_state == "missing":
                        rp_supervisor.latch_fault(
                            callback_index=None,
                            sensor_frame=frame,
                            reason="lidar_callback_timeout",
                        )
                    elif frame_state == "callback_error":
                        rp_supervisor.latch_fault(
                            callback_index=None,
                            sensor_frame=frame,
                            reason="lidar_callback_error",
                        )

                transform = ego_vehicle.get_transform()
                velocity = ego_vehicle.get_velocity()
                snap = _transform_snapshot(transform, velocity)
                snap["frame"] = frame
                snap["tick_index"] = tick_idx
                samples.append(snap)
                speed_values.append(snap["speed_mps"])

                if tick_idx % 50 == 0:
                    print(
                        f"[carla-harness] tick={tick_idx}/{cfg.ticks} "
                        f"speed={snap['speed_mps']:.2f} m/s "
                        f"collisions={len(collision_events)}",
                        flush=True,
                    )

                # --- Runtime protection enforcement -------------------------
                if cfg.runtime_protection_enabled and rp_supervisor.triggered:
                    rp_state = rp_supervisor.enforce(
                        ego_vehicle,
                        tick_idx,
                        disable_autopilot=_disable_autopilot,
                        apply_control=_apply_braking_control,
                    )
                    if rp_supervisor.terminal:
                        print(
                            f"[carla-harness] runtime protection: "
                            f"state={rp_state.value} tick={tick_idx} "
                            f"ticks_completed={ticks_completed}",
                            flush=True,
                        )
                        break
        except Exception as exc:  # noqa: BLE001
            print(f"[carla-harness] tick loop error: {exc}", file=sys.stderr)
            traceback.print_exc()
            missing_data_count += cfg.ticks - ticks_completed
            # Do not raise; partial data is acceptable; cleanup follows.

        # Compute displacement
        final_transform = ego_vehicle.get_transform()
        end_pos = (
            final_transform.location.x,
            final_transform.location.y,
            final_transform.location.z,
        )
        disp = _displacement(start_pos, end_pos)

        mean_speed = sum(speed_values) / len(speed_values) if speed_values else 0.0
        max_speed = max(speed_values) if speed_values else 0.0

        # Lidar summary
        lidar_frame_evidence: list[dict[str, Any]] = []
        lidar_summary_dict: dict[str, Any] = {}
        lidar_snap: LidarCollectorSnapshot | None = None
        if lidar_collector is not None:
            lidar_snap = lidar_collector.snapshot()
            summary = build_lidar_summary(
                lidar_snap.accepted_frames,
                lidar_snap.natural_drops,
                lidar_snap.injected_drops,
                lidar_snap.callback_errors,
            )
            lidar_summary_dict = summary.as_dict()
            lidar_frame_evidence = [f.as_dict() for f in lidar_snap.accepted_frames]
        else:
            lidar_summary_dict = {
                "frames_received": 0,
                "frames_dropped": 0,
                "natural_drops": 0,
                "injected_drops": 0,
                "callback_errors": 0,
                "total_points": 0,
                "total_invalid": 0,
                "nearest_obstacle_overall": None,
                "nearest_obstacle_front": None,
                "mean_nearest_front": None,
            }

        # --- Build run report -----------------------------------------------
        # Fault injection accounting (assembled before QRTC so evidence is always present)
        fault_requested = cfg.lidar.drop_frame_index >= 0
        fault_injection_section: dict[str, Any] = {
            "enabled": fault_requested,
            "type": "lidar-frame-drop" if fault_requested else None,
            "requested_callback_index": (
                cfg.lidar.drop_frame_index if fault_requested else None
            ),
            "triggered": False,
            "triggered_callback_index": None,
            "triggered_sensor_frame": None,
        }
        lidar_callbacks_received: int = 0
        lidar_frames_accepted: int = 0
        lidar_frames_natural_dropped: int = 0
        lidar_frames_injected_dropped: int = 0
        if lidar_snap is not None:
            fault_injection_section.update(
                {
                    "triggered": lidar_snap.fault_injection_triggered,
                    "triggered_callback_index": lidar_snap.triggered_callback_index,
                    "triggered_sensor_frame": lidar_snap.triggered_sensor_frame,
                }
            )
            lidar_callbacks_received = lidar_snap.callbacks_received
            lidar_frames_accepted = len(lidar_snap.accepted_frames)
            lidar_frames_natural_dropped = lidar_snap.natural_drops
            lidar_frames_injected_dropped = lidar_snap.injected_drops

        rp_snapshot = rp_supervisor.snapshot()
        status = "completed" if ticks_completed == cfg.ticks else "partial"
        if rp_snapshot.state == RuntimeProtectionState.CONTROL_ERROR:
            status = "aborted"

        run_report: dict[str, Any] = {
            "run_id": run_id,
            "run_timestamp_utc": run_ts,
            "status": status,
            "client_version": client_version,
            "server_version": server_version,
            "map_name": map_name,
            "blueprint": actor_type_id,
            "actor_id": actor_id,
            "actor_type_id": actor_type_id,
            "spawn_point_index": actual_spawn_index,
            "ticks_requested": cfg.ticks,
            "ticks_completed": ticks_completed,
            "terminated_early": ticks_completed < cfg.ticks,
            "missing_data_count": missing_data_count,
            "principal": cfg.principal,
            "destination": cfg.destination,
            "config": cfg.as_dict(),
            "summary": {
                "collision_count": len(collision_events),
                "displacement_m": disp,
                "mean_speed_mps": mean_speed,
                "max_speed_mps": max_speed,
            },
            "collision_events": collision_events,
            "samples": samples,
            "lidar_summary": lidar_summary_dict,
            "lidar_frame_evidence": lidar_frame_evidence,
            "fault_injection": fault_injection_section,
            "lidar_callbacks_received": lidar_callbacks_received,
            "lidar_frames_accepted": lidar_frames_accepted,
            "lidar_frames_natural_dropped": lidar_frames_natural_dropped,
            "lidar_frames_injected_dropped": lidar_frames_injected_dropped,
            "runtime_protection": rp_snapshot.as_dict(),
        }

        # Emit config and evidence digests
        from qrtc.carla_telemetry import _config_digest, _evidence_digest

        run_report["config_digest"] = _config_digest(cfg.as_dict())
        run_report["evidence_digest"] = _evidence_digest(run_report["summary"])

        # --- Write output ---------------------------------------------------
        out_path = Path(cfg.output)
        try:
            out_path.write_text(
                json.dumps(run_report, indent=2, default=str),
                encoding="utf-8",
            )
            print(f"[carla-harness] report written to {out_path}", flush=True)
        except OSError as exc:
            print(f"[carla-harness] output write failed: {exc}", file=sys.stderr)
            raise SystemExit(4) from exc

        # --- Optional QRTC submission ---------------------------------------
        if cfg.submit_to_qrtc:
            projection = build_qrtc_projection(run_report)
            qrtc_result = submit_to_qrtc_pipeline(
                projection,
                db_path=cfg.qrtc_db,
                carla_principal=cfg.principal,
            )
            run_report["qrtc_submission"] = qrtc_result.as_dict()
            print(
                f"[carla-harness] QRTC submission: status={qrtc_result.status} "
                f"transit_id={qrtc_result.transit_id} db={qrtc_result.db_path}",
                flush=True,
            )

            classification = _classify_post_run_rejection(
                cfg,
                run_report,
                run_report["qrtc_submission"],
            )
            run_report["post_run_rejection_test_passed"] = (
                classification.post_run_rejection_test_passed
            )
            if not classification.fault_requested:
                run_report.pop("fault_requested", None)
                run_report.pop("fault_observed", None)
            else:
                run_report["fault_requested"] = classification.fault_requested
                run_report["fault_observed"] = classification.fault_observed

            # Runtime protection classification (requires QRTC result)
            rp_classification = _classify_runtime_protection(
                cfg,
                run_report,
                run_report["qrtc_submission"],
            )
            run_report["test_outcome"] = (
                rp_classification.test_outcome
                if cfg.runtime_protection_enabled
                else classification.test_outcome
            )
            run_report["runtime_protection_test_passed"] = (
                rp_classification.runtime_protection_test_passed
            )

            # Rewrite with QRTC result and classification included
            out_path.write_text(
                json.dumps(run_report, indent=2, default=str),
                encoding="utf-8",
            )
        else:
            # No QRTC submission — post_run_rejection_test_passed must remain False.
            classification = _classify_post_run_rejection(cfg, run_report)
            run_report["post_run_rejection_test_passed"] = (
                classification.post_run_rejection_test_passed
            )
            if classification.fault_requested:
                run_report["fault_requested"] = classification.fault_requested
                run_report["fault_observed"] = classification.fault_observed

            # Runtime protection classification without QRTC
            rp_classification = _classify_runtime_protection(cfg, run_report)
            run_report["test_outcome"] = (
                rp_classification.test_outcome
                if cfg.runtime_protection_enabled
                else classification.test_outcome
            )
            run_report["runtime_protection_test_passed"] = (
                rp_classification.runtime_protection_test_passed
            )

            # Rewrite with classification
            out_path.write_text(
                json.dumps(run_report, indent=2, default=str),
                encoding="utf-8",
            )

        return run_report

    finally:
        # --- Cleanup (always executed) --------------------------------------
        print("[carla-harness] cleaning up ...", flush=True)
        if ego_vehicle is not None:
            try:
                ego_vehicle.set_autopilot(False)
            except Exception:  # noqa: BLE001,S110
                pass
        for sensor in (lidar_sensor, collision_sensor):
            if sensor is not None:
                try:
                    sensor.stop()
                except Exception:  # noqa: BLE001,S110
                    pass
                try:
                    sensor.destroy()
                except Exception:  # noqa: BLE001,S110
                    pass
        if ego_vehicle is not None:
            try:
                ego_vehicle.destroy()
            except Exception:  # noqa: BLE001,S110
                pass
        try:
            tm.set_synchronous_mode(False)
        except Exception:  # noqa: BLE001,S110
            pass
        try:
            world.apply_settings(original_settings)
        except Exception:  # noqa: BLE001,S110
            pass
        print("[carla-harness] cleanup complete", flush=True)


# ---------------------------------------------------------------------------
# Console entry point
# ---------------------------------------------------------------------------


def _build_parser() -> argparse.ArgumentParser:
    return argparse.ArgumentParser(
        prog="carla-live-drive",
        description=(
            "Run the optional CARLA live-drive harness. Configuration is provided "
            "through CARLA_* environment variables."
        ),
    )


def main(argv: list[str] | None = None) -> int:
    """Entry point for the ``carla-live-drive`` console script."""
    if argv is None:
        argv = [] if "pytest" in sys.modules else sys.argv[1:]
    _build_parser().parse_args(argv)
    cfg = carla_config_from_env()
    errors = validate_carla_config(cfg)
    if errors:
        for e in errors:
            print(f"config error: {e}", file=sys.stderr)
        return 1

    try:
        report = run_drive(cfg)
    except SystemExit as exc:
        return int(exc.code) if exc.code is not None else 1
    except Exception as exc:  # noqa: BLE001
        print(f"[carla-harness] fatal: {exc}", file=sys.stderr)
        traceback.print_exc()
        return 10

    status = report.get("status", "unknown")
    print(f"[carla-harness] done status={status}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
